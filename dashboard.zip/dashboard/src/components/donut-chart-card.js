import React from "react";
import Plotly from "plotly.js";
import createPlotlyComponent from "react-plotly.js/factory";

const Plot = createPlotlyComponent(Plotly);

const layout = {
  annotations: [
    {
      font: {
        size: 20,
      },
      showarrow: false,
      text: "",
      x: 0.5,
      y: 0.5,
    },
  ],
  uniformtext:{
    mode:'hide',
    minsize:'10'
  }
};

const config = {
  displayModeBar: false,
};

const DonutChartCard = ({ values, labels, hoverText, name, chartClick }) => {
  console.log(hoverText)
  const handleChartClick = (el) => {
    chartClick(name==="Roles"?'role':'level',el.points[0].label)
  }
  return (
    <div className="card shadow-sm">
      <Plot
        data={[
          {
            values,
            labels,
            name,
            hovertext:hoverText,
            hoverinfo: 'text',
            hole: 0.6,
            type: "pie",
            textposition: "inside",
            automargin: true,
            marker:{
              line:{
                color:'#fff',
                width:'2'
              }
            }
          },
        ]}
        layout={{
          ...layout,
          title: {
            text: name,
            font:{
              size:25
            },
            x: 0.05,
          },
        }}
        config={config}
        useResizeHandler
        style={{ width: "100%", height: "100%" }}
        onClick={(elem) => {
          console.log(elem);
          handleChartClick(elem);
        }}
      />
    </div>
  );
};

export default DonutChartCard;
