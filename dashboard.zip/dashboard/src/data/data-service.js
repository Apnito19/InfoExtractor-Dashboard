import { TOKEN } from "../constants";

export class DataService {
  data = [];

  static async getData() {
    let tempData = null;
    try{
      tempData = await(await fetch("https://api.oneshot.ai/api/crm/contact/jobtitles",{
      method:"GET",
      headers: {
        "Authorization": `Bearer ${TOKEN}` ,
        }
      })).json()
    } 
    catch {
      alert("Token Expired")
    }
    
    if(tempData["results"]){
      try {
        this.data = await(await fetch(
          "http://3.8.144.18:5000",
          {
            method: "POST",
            body: JSON.stringify(tempData["results"]),
            headers: {
              "Content-type": "application/json",
            },
          }
        )).json();
        
      } catch {
        alert("Failed to fetch data");
      }
    }
    
  }
}
