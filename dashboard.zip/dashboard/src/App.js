import React from "react";
import "./App.css";
import logo from './static/images/dashboard.png';
import MainContainer from "./components/main-container";


function App() {
  return (
    <div className="App container-fluid my-3">
      <img src={logo} alt="Dashboard" />
      <MainContainer />
    </div>
  );
}

export default App;
